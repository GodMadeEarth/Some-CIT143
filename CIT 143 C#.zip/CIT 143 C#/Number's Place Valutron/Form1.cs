﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Timothy M Campbell
// Lab 2 Part 4

namespace Number_s_Place_Valutron
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int onesDigit;
            int tensDigit;
            int hundredsDigit;
            int thousandsDigit;
            int digitSum;

            onesDigit = int.Parse(numberTextBox.Text) % 10;
            oneDigitLabel.Text = onesDigit.ToString();

            tensDigit = int.Parse(numberTextBox.Text) % 100 / 10;
            tenDigitLable .Text = tensDigit.ToString();

            hundredsDigit = int.Parse(numberTextBox.Text) % 1000 / 100;
            hundredDigitLabel.Text = hundredsDigit.ToString();

            thousandsDigit = int.Parse(numberTextBox.Text) % 10000 / 1000;
            thousandDigitLable .Text = thousandsDigit.ToString();

            digitSum = onesDigit + tensDigit + 
                hundredsDigit + thousandsDigit;
            digitSumLabel.Text = digitSum.ToString();

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            this.numberTextBox.Text = "";

            this.oneDigitLabel.Text = "0";
            this.tenDigitLable.Text = "0";
            this.hundredDigitLabel.Text = "0";
            this.thousandDigitLable.Text = "0";

            this.digitSumLabel.Text = "0";
        }

        private void quitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
