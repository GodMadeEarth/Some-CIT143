﻿namespace Number_s_Place_Valutron
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.numberPromptLabel = new System.Windows.Forms.Label();
            this.thousandDigitLable = new System.Windows.Forms.Label();
            this.hundredDigitLabel = new System.Windows.Forms.Label();
            this.tenDigitLable = new System.Windows.Forms.Label();
            this.oneDigitLabel = new System.Windows.Forms.Label();
            this.equalLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.quitButton = new System.Windows.Forms.Button();
            this.digitSumLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // numberTextBox
            // 
            this.numberTextBox.Location = new System.Drawing.Point(170, 15);
            this.numberTextBox.MaxLength = 4;
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(119, 20);
            this.numberTextBox.TabIndex = 0;
            // 
            // numberPromptLabel
            // 
            this.numberPromptLabel.AutoSize = true;
            this.numberPromptLabel.Location = new System.Drawing.Point(27, 18);
            this.numberPromptLabel.Name = "numberPromptLabel";
            this.numberPromptLabel.Size = new System.Drawing.Size(125, 13);
            this.numberPromptLabel.TabIndex = 1;
            this.numberPromptLabel.Text = "Enter a four digit number:";
            // 
            // thousandDigitLable
            // 
            this.thousandDigitLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.thousandDigitLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thousandDigitLable.ForeColor = System.Drawing.Color.Black;
            this.thousandDigitLable.Location = new System.Drawing.Point(15, 41);
            this.thousandDigitLable.Name = "thousandDigitLable";
            this.thousandDigitLable.Size = new System.Drawing.Size(32, 32);
            this.thousandDigitLable.TabIndex = 2;
            this.thousandDigitLable.Text = "0";
            this.thousandDigitLable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hundredDigitLabel
            // 
            this.hundredDigitLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hundredDigitLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hundredDigitLabel.Location = new System.Drawing.Point(53, 41);
            this.hundredDigitLabel.Name = "hundredDigitLabel";
            this.hundredDigitLabel.Size = new System.Drawing.Size(32, 32);
            this.hundredDigitLabel.TabIndex = 3;
            this.hundredDigitLabel.Text = "0";
            this.hundredDigitLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tenDigitLable
            // 
            this.tenDigitLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tenDigitLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tenDigitLable.Location = new System.Drawing.Point(91, 41);
            this.tenDigitLable.Name = "tenDigitLable";
            this.tenDigitLable.Size = new System.Drawing.Size(32, 32);
            this.tenDigitLable.TabIndex = 4;
            this.tenDigitLable.Text = "0";
            this.tenDigitLable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // oneDigitLabel
            // 
            this.oneDigitLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.oneDigitLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oneDigitLabel.Location = new System.Drawing.Point(129, 41);
            this.oneDigitLabel.Name = "oneDigitLabel";
            this.oneDigitLabel.Size = new System.Drawing.Size(32, 32);
            this.oneDigitLabel.TabIndex = 5;
            this.oneDigitLabel.Text = "0";
            this.oneDigitLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // equalLabel
            // 
            this.equalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.equalLabel.Location = new System.Drawing.Point(167, 41);
            this.equalLabel.Name = "equalLabel";
            this.equalLabel.Size = new System.Drawing.Size(32, 32);
            this.equalLabel.TabIndex = 6;
            this.equalLabel.Text = "=";
            this.equalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(12, 92);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(99, 35);
            this.calculateButton.TabIndex = 7;
            this.calculateButton.Text = "Calculate Digits and Their Sum";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(129, 92);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 35);
            this.clearButton.TabIndex = 8;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // quitButton
            // 
            this.quitButton.Location = new System.Drawing.Point(226, 92);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(75, 35);
            this.quitButton.TabIndex = 9;
            this.quitButton.Text = "Quit";
            this.quitButton.UseVisualStyleBackColor = true;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // digitSumLabel
            // 
            this.digitSumLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.digitSumLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.digitSumLabel.Location = new System.Drawing.Point(205, 41);
            this.digitSumLabel.Name = "digitSumLabel";
            this.digitSumLabel.Size = new System.Drawing.Size(64, 32);
            this.digitSumLabel.TabIndex = 10;
            this.digitSumLabel.Text = "0";
            this.digitSumLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(313, 134);
            this.Controls.Add(this.digitSumLabel);
            this.Controls.Add(this.quitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.equalLabel);
            this.Controls.Add(this.oneDigitLabel);
            this.Controls.Add(this.tenDigitLable);
            this.Controls.Add(this.hundredDigitLabel);
            this.Controls.Add(this.thousandDigitLable);
            this.Controls.Add(this.numberPromptLabel);
            this.Controls.Add(this.numberTextBox);
            this.Name = "Form1";
            this.Text = "Number\'s Place Valutron";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.Label numberPromptLabel;
        private System.Windows.Forms.Label thousandDigitLable;
        private System.Windows.Forms.Label hundredDigitLabel;
        private System.Windows.Forms.Label tenDigitLable;
        private System.Windows.Forms.Label oneDigitLabel;
        private System.Windows.Forms.Label equalLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button quitButton;
        private System.Windows.Forms.Label digitSumLabel;
    }
}

