﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Timothy M Campbell
//Lab 2 Part 1

namespace Birth_Date_String_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showDateButton_Click(object sender, EventArgs e)
        {
            string output;

            output = dayOfWeekTextBox.Text + ", " + 
                monthTextBox.Text + " " + 
                dayOfMonthTextBox.Text + ", " + 
                yearTextBox.Text;

            dateOutputLable.Text = output;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            this.dayOfMonthTextBox.Text = "";
            this.dayOfWeekTextBox.Text = "";
            this.monthTextBox.Text = "";
            this.yearTextBox.Text = "";

            this.dateOutputLable.Text = "";
        }

        private void quitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
