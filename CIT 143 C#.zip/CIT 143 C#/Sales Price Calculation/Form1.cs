﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Timothy M Campbell
// Lab 2 Part 3

namespace Fuel_Economy_Calculation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            decimal originalPrice;
            decimal discountPercentage;
            decimal discountAmount;
            decimal salePrice;
            try
            {

            }
            originalPrice = decimal.Parse(this.originalPriceTextBox.Text);

            discountPercentage = decimal.Parse(this.discountPercentageTextBox.Text);
            discountPercentage = discountPercentage / 100;
            
            discountAmount = originalPrice * discountPercentage;

            salePrice = originalPrice - discountAmount;

            salePriceLabel.Text = salePrice.ToString("C");
        }

        private void quitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            originalPriceTextBox.Text = string.Empty;
            discountPercentageTextBox.Text = string.Empty;
            salePriceLabel.Text = string.Empty;
        }
    }
}
