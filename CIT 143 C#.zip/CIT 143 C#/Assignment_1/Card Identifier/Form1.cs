﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Timothy M Campbell
// Assignment 1 Part 1

namespace Flags
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void eightClubPictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "Eight of Clubs";
        }

        private void sevenHeartPictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "Seven of Hearts";
        }

        private void queenSpadePictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "Queen of Spades";
        }

        private void aceHeartPictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "Ace of Hearts";
        }

        private void tenClubPictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "Ten of Clubs";
        }
    }


    
}
