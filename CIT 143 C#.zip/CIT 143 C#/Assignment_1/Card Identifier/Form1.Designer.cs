﻿namespace Flags
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.eightClubPictureBox = new System.Windows.Forms.PictureBox();
            this.instructionLable = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.sevenHeartPictureBox = new System.Windows.Forms.PictureBox();
            this.queenSpadePictureBox = new System.Windows.Forms.PictureBox();
            this.aceHeartPictureBox = new System.Windows.Forms.PictureBox();
            this.tenClubPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.eightClubPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenHeartPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenSpadePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceHeartPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenClubPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // eightClubPictureBox
            // 
            this.eightClubPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.eightClubPictureBox.Image = global::Flags.Properties.Resources._8_Clubs;
            this.eightClubPictureBox.Location = new System.Drawing.Point(12, 42);
            this.eightClubPictureBox.Name = "eightClubPictureBox";
            this.eightClubPictureBox.Size = new System.Drawing.Size(100, 140);
            this.eightClubPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.eightClubPictureBox.TabIndex = 0;
            this.eightClubPictureBox.TabStop = false;
            this.eightClubPictureBox.Click += new System.EventHandler(this.eightClubPictureBox_Click);
            // 
            // instructionLable
            // 
            this.instructionLable.AutoSize = true;
            this.instructionLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionLable.Location = new System.Drawing.Point(154, 9);
            this.instructionLable.Name = "instructionLable";
            this.instructionLable.Size = new System.Drawing.Size(228, 18);
            this.instructionLable.TabIndex = 3;
            this.instructionLable.Text = "Click a card to see it\'s name.";
            // 
            // numberLabel
            // 
            this.numberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberLabel.Location = new System.Drawing.Point(157, 206);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(225, 23);
            this.numberLabel.TabIndex = 4;
            this.numberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sevenHeartPictureBox
            // 
            this.sevenHeartPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sevenHeartPictureBox.Image = global::Flags.Properties.Resources._7_Hearts;
            this.sevenHeartPictureBox.Location = new System.Drawing.Point(118, 42);
            this.sevenHeartPictureBox.Name = "sevenHeartPictureBox";
            this.sevenHeartPictureBox.Size = new System.Drawing.Size(100, 140);
            this.sevenHeartPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sevenHeartPictureBox.TabIndex = 5;
            this.sevenHeartPictureBox.TabStop = false;
            this.sevenHeartPictureBox.Click += new System.EventHandler(this.sevenHeartPictureBox_Click);
            // 
            // queenSpadePictureBox
            // 
            this.queenSpadePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.queenSpadePictureBox.Image = global::Flags.Properties.Resources.Queen_Spades;
            this.queenSpadePictureBox.Location = new System.Drawing.Point(224, 42);
            this.queenSpadePictureBox.Name = "queenSpadePictureBox";
            this.queenSpadePictureBox.Size = new System.Drawing.Size(100, 140);
            this.queenSpadePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.queenSpadePictureBox.TabIndex = 6;
            this.queenSpadePictureBox.TabStop = false;
            this.queenSpadePictureBox.Click += new System.EventHandler(this.queenSpadePictureBox_Click);
            // 
            // aceHeartPictureBox
            // 
            this.aceHeartPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aceHeartPictureBox.Image = global::Flags.Properties.Resources.Ace_Hearts;
            this.aceHeartPictureBox.Location = new System.Drawing.Point(330, 42);
            this.aceHeartPictureBox.Name = "aceHeartPictureBox";
            this.aceHeartPictureBox.Size = new System.Drawing.Size(100, 140);
            this.aceHeartPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.aceHeartPictureBox.TabIndex = 7;
            this.aceHeartPictureBox.TabStop = false;
            this.aceHeartPictureBox.Click += new System.EventHandler(this.aceHeartPictureBox_Click);
            // 
            // tenClubPictureBox
            // 
            this.tenClubPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tenClubPictureBox.Image = global::Flags.Properties.Resources._10_Clubs;
            this.tenClubPictureBox.Location = new System.Drawing.Point(436, 42);
            this.tenClubPictureBox.Name = "tenClubPictureBox";
            this.tenClubPictureBox.Size = new System.Drawing.Size(100, 140);
            this.tenClubPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tenClubPictureBox.TabIndex = 8;
            this.tenClubPictureBox.TabStop = false;
            this.tenClubPictureBox.Click += new System.EventHandler(this.tenClubPictureBox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 238);
            this.Controls.Add(this.tenClubPictureBox);
            this.Controls.Add(this.aceHeartPictureBox);
            this.Controls.Add(this.queenSpadePictureBox);
            this.Controls.Add(this.sevenHeartPictureBox);
            this.Controls.Add(this.numberLabel);
            this.Controls.Add(this.instructionLable);
            this.Controls.Add(this.eightClubPictureBox);
            this.Name = "Form1";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.eightClubPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sevenHeartPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenSpadePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceHeartPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenClubPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox eightClubPictureBox;
        private System.Windows.Forms.Label instructionLable;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.PictureBox sevenHeartPictureBox;
        private System.Windows.Forms.PictureBox queenSpadePictureBox;
        private System.Windows.Forms.PictureBox aceHeartPictureBox;
        private System.Windows.Forms.PictureBox tenClubPictureBox;
    }
}

