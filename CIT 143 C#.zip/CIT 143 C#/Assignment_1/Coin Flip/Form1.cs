﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Timothy M Campbell
// Assignment 1 Part 2

namespace Coin_Flip
{
    public partial class Form1 : Form
    {
        Image coinHeads = Properties.Resources.Heads1;
        Image coinTails = Properties.Resources.Tails1;
        public Form1()
        {
            InitializeComponent();
            coinPictureBox.Image = coinHeads;
        }

        private void coinFlipButton_Click(object sender, EventArgs e)
        {
            if (coinPictureBox.Image == coinHeads)
            {
                coinPictureBox.Image = coinTails;
                coinFlipButton.Text = "Flip to Heads";
            }
            else
            {
                coinPictureBox.Image = coinHeads;
                coinFlipButton.Text = "Flip to Tails";
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
