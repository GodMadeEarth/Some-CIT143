﻿namespace Coin_Flip
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.coinPictureBox = new System.Windows.Forms.PictureBox();
            this.coinFlipButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.coinPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // coinPictureBox
            // 
            this.coinPictureBox.Image = global::Coin_Flip.Properties.Resources.Heads1;
            this.coinPictureBox.Location = new System.Drawing.Point(12, 12);
            this.coinPictureBox.Name = "coinPictureBox";
            this.coinPictureBox.Size = new System.Drawing.Size(160, 160);
            this.coinPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.coinPictureBox.TabIndex = 0;
            this.coinPictureBox.TabStop = false;
            // 
            // coinFlipButton
            // 
            this.coinFlipButton.Location = new System.Drawing.Point(12, 206);
            this.coinFlipButton.Name = "coinFlipButton";
            this.coinFlipButton.Size = new System.Drawing.Size(96, 23);
            this.coinFlipButton.TabIndex = 1;
            this.coinFlipButton.Text = "Flip to Tails";
            this.coinFlipButton.UseVisualStyleBackColor = true;
            this.coinFlipButton.Click += new System.EventHandler(this.coinFlipButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(114, 206);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(58, 23);
            this.closeButton.TabIndex = 2;
            this.closeButton.TabStop = false;
            this.closeButton.Text = "Quit";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(220, 241);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.coinFlipButton);
            this.Controls.Add(this.coinPictureBox);
            this.Name = "Form1";
            this.Text = "Coin Flip";
            ((System.ComponentModel.ISupportInitialize)(this.coinPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox coinPictureBox;
        private System.Windows.Forms.Button coinFlipButton;
        private System.Windows.Forms.Button closeButton;
    }
}

