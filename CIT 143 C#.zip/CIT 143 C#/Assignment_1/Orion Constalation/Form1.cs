﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Timothy M Campbell
// Assignment 1 Part 3

namespace Orion_Constalation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showStarNamesButton_Click(object sender, EventArgs e)
        {
            this.alnilamLabel.Visible = true;
            this.alnitakLabel.Visible = true;
            this.betelgeuseLabel.Visible = true;
            this.meissaLabel.Visible = true;
            this.minitakaLabel.Visible = true;
            this.rigelLabel.Visible = true;
            this.saiphLabel.Visible = true;
        }

        private void hideStarNamesButton_Click(object sender, EventArgs e)
        {
            this.alnilamLabel.Visible = false;
            this.alnitakLabel.Visible = false;
            this.betelgeuseLabel.Visible = false;
            this.meissaLabel.Visible = false;
            this.minitakaLabel.Visible = false;
            this.rigelLabel.Visible = false;
            this.saiphLabel.Visible = false;
        }

        private void quitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saiphLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
