﻿namespace Orion_Constalation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.orionConstilationpictureBox = new System.Windows.Forms.PictureBox();
            this.showStarNamesButton = new System.Windows.Forms.Button();
            this.quitButton = new System.Windows.Forms.Button();
            this.hideStarNamesButton = new System.Windows.Forms.Button();
            this.betelgeuseLabel = new System.Windows.Forms.Label();
            this.meissaLabel = new System.Windows.Forms.Label();
            this.alnitakLabel = new System.Windows.Forms.Label();
            this.minitakaLabel = new System.Windows.Forms.Label();
            this.alnilamLabel = new System.Windows.Forms.Label();
            this.saiphLabel = new System.Windows.Forms.Label();
            this.rigelLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.orionConstilationpictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // orionConstilationpictureBox
            // 
            this.orionConstilationpictureBox.Image = global::Orion_Constalation.Properties.Resources.Orion;
            this.orionConstilationpictureBox.Location = new System.Drawing.Point(9, 12);
            this.orionConstilationpictureBox.Name = "orionConstilationpictureBox";
            this.orionConstilationpictureBox.Size = new System.Drawing.Size(400, 470);
            this.orionConstilationpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.orionConstilationpictureBox.TabIndex = 0;
            this.orionConstilationpictureBox.TabStop = false;
            // 
            // showStarNamesButton
            // 
            this.showStarNamesButton.Location = new System.Drawing.Point(12, 499);
            this.showStarNamesButton.Name = "showStarNamesButton";
            this.showStarNamesButton.Size = new System.Drawing.Size(115, 23);
            this.showStarNamesButton.TabIndex = 1;
            this.showStarNamesButton.Text = "Show Star Names";
            this.showStarNamesButton.UseVisualStyleBackColor = true;
            this.showStarNamesButton.Click += new System.EventHandler(this.showStarNamesButton_Click);
            // 
            // quitButton
            // 
            this.quitButton.Location = new System.Drawing.Point(334, 499);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(75, 23);
            this.quitButton.TabIndex = 2;
            this.quitButton.Text = "Quit";
            this.quitButton.UseVisualStyleBackColor = true;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // hideStarNamesButton
            // 
            this.hideStarNamesButton.Location = new System.Drawing.Point(182, 499);
            this.hideStarNamesButton.Name = "hideStarNamesButton";
            this.hideStarNamesButton.Size = new System.Drawing.Size(97, 23);
            this.hideStarNamesButton.TabIndex = 3;
            this.hideStarNamesButton.Text = "Hide Star Names";
            this.hideStarNamesButton.UseVisualStyleBackColor = true;
            this.hideStarNamesButton.Click += new System.EventHandler(this.hideStarNamesButton_Click);
            // 
            // betelgeuseLabel
            // 
            this.betelgeuseLabel.AutoSize = true;
            this.betelgeuseLabel.Location = new System.Drawing.Point(102, 59);
            this.betelgeuseLabel.Name = "betelgeuseLabel";
            this.betelgeuseLabel.Size = new System.Drawing.Size(60, 13);
            this.betelgeuseLabel.TabIndex = 4;
            this.betelgeuseLabel.Text = "Betelgeuse";
            this.betelgeuseLabel.Visible = false;
            // 
            // meissaLabel
            // 
            this.meissaLabel.AutoSize = true;
            this.meissaLabel.Location = new System.Drawing.Point(301, 94);
            this.meissaLabel.Name = "meissaLabel";
            this.meissaLabel.Size = new System.Drawing.Size(40, 13);
            this.meissaLabel.TabIndex = 5;
            this.meissaLabel.Text = "Meissa";
            this.meissaLabel.Visible = false;
            // 
            // alnitakLabel
            // 
            this.alnitakLabel.AutoSize = true;
            this.alnitakLabel.Location = new System.Drawing.Point(88, 240);
            this.alnitakLabel.Name = "alnitakLabel";
            this.alnitakLabel.Size = new System.Drawing.Size(39, 13);
            this.alnitakLabel.TabIndex = 6;
            this.alnitakLabel.Text = "Alnitak";
            this.alnitakLabel.Visible = false;
            // 
            // minitakaLabel
            // 
            this.minitakaLabel.AutoSize = true;
            this.minitakaLabel.Location = new System.Drawing.Point(244, 212);
            this.minitakaLabel.Name = "minitakaLabel";
            this.minitakaLabel.Size = new System.Drawing.Size(47, 13);
            this.minitakaLabel.TabIndex = 7;
            this.minitakaLabel.Text = "Minitaka";
            this.minitakaLabel.Visible = false;
            // 
            // alnilamLabel
            // 
            this.alnilamLabel.AutoSize = true;
            this.alnilamLabel.Location = new System.Drawing.Point(195, 240);
            this.alnilamLabel.Name = "alnilamLabel";
            this.alnilamLabel.Size = new System.Drawing.Size(40, 13);
            this.alnilamLabel.TabIndex = 8;
            this.alnilamLabel.Text = "Alnilam";
            this.alnilamLabel.Visible = false;
            // 
            // saiphLabel
            // 
            this.saiphLabel.AutoSize = true;
            this.saiphLabel.Location = new System.Drawing.Point(102, 400);
            this.saiphLabel.Name = "saiphLabel";
            this.saiphLabel.Size = new System.Drawing.Size(34, 13);
            this.saiphLabel.TabIndex = 9;
            this.saiphLabel.Text = "Saiph";
            this.saiphLabel.Visible = false;
            this.saiphLabel.Click += new System.EventHandler(this.saiphLabel_Click);
            // 
            // rigelLabel
            // 
            this.rigelLabel.AutoSize = true;
            this.rigelLabel.Location = new System.Drawing.Point(291, 369);
            this.rigelLabel.Name = "rigelLabel";
            this.rigelLabel.Size = new System.Drawing.Size(31, 13);
            this.rigelLabel.TabIndex = 10;
            this.rigelLabel.Text = "Rigel";
            this.rigelLabel.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 534);
            this.Controls.Add(this.rigelLabel);
            this.Controls.Add(this.saiphLabel);
            this.Controls.Add(this.alnilamLabel);
            this.Controls.Add(this.minitakaLabel);
            this.Controls.Add(this.alnitakLabel);
            this.Controls.Add(this.meissaLabel);
            this.Controls.Add(this.betelgeuseLabel);
            this.Controls.Add(this.hideStarNamesButton);
            this.Controls.Add(this.quitButton);
            this.Controls.Add(this.showStarNamesButton);
            this.Controls.Add(this.orionConstilationpictureBox);
            this.Name = "Form1";
            this.Text = "Orion Constalation";
            ((System.ComponentModel.ISupportInitialize)(this.orionConstilationpictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox orionConstilationpictureBox;
        private System.Windows.Forms.Button showStarNamesButton;
        private System.Windows.Forms.Button quitButton;
        private System.Windows.Forms.Button hideStarNamesButton;
        private System.Windows.Forms.Label betelgeuseLabel;
        private System.Windows.Forms.Label meissaLabel;
        private System.Windows.Forms.Label alnitakLabel;
        private System.Windows.Forms.Label minitakaLabel;
        private System.Windows.Forms.Label alnilamLabel;
        private System.Windows.Forms.Label saiphLabel;
        private System.Windows.Forms.Label rigelLabel;
    }
}

