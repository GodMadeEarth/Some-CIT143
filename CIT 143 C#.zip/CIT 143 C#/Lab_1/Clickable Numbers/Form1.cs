﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flags
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void numberOnePictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "One";
        }

        private void numberTwoPictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "Two";
        }

        private void numberThreePictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "Three";
        }

        private void numberFourPictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "Four";
        }

        private void numberFivePictureBox_Click(object sender, EventArgs e)
        {
            numberLabel.Text = "Five";
        }
    }


    
}
