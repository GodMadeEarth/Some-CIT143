﻿namespace Flags
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numberOnePictureBox = new System.Windows.Forms.PictureBox();
            this.instructionLable = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.numberTwoPictureBox = new System.Windows.Forms.PictureBox();
            this.numberThreePictureBox = new System.Windows.Forms.PictureBox();
            this.numberFourPictureBox = new System.Windows.Forms.PictureBox();
            this.numberFivePictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.numberOnePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numberTwoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numberThreePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numberFourPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numberFivePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // numberOnePictureBox
            // 
            this.numberOnePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberOnePictureBox.Image = global::Flags.Properties.Resources.One;
            this.numberOnePictureBox.Location = new System.Drawing.Point(15, 42);
            this.numberOnePictureBox.Name = "numberOnePictureBox";
            this.numberOnePictureBox.Size = new System.Drawing.Size(82, 146);
            this.numberOnePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.numberOnePictureBox.TabIndex = 0;
            this.numberOnePictureBox.TabStop = false;
            this.numberOnePictureBox.Click += new System.EventHandler(this.numberOnePictureBox_Click);
            // 
            // instructionLable
            // 
            this.instructionLable.AutoSize = true;
            this.instructionLable.Location = new System.Drawing.Point(157, 9);
            this.instructionLable.Name = "instructionLable";
            this.instructionLable.Size = new System.Drawing.Size(156, 13);
            this.instructionLable.TabIndex = 3;
            this.instructionLable.Text = "Click a number to see it\'s name.";
            // 
            // numberLabel
            // 
            this.numberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberLabel.Location = new System.Drawing.Point(193, 216);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(82, 23);
            this.numberLabel.TabIndex = 4;
            this.numberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numberTwoPictureBox
            // 
            this.numberTwoPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberTwoPictureBox.Image = global::Flags.Properties.Resources.Two;
            this.numberTwoPictureBox.Location = new System.Drawing.Point(105, 42);
            this.numberTwoPictureBox.Name = "numberTwoPictureBox";
            this.numberTwoPictureBox.Size = new System.Drawing.Size(82, 146);
            this.numberTwoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.numberTwoPictureBox.TabIndex = 5;
            this.numberTwoPictureBox.TabStop = false;
            this.numberTwoPictureBox.Click += new System.EventHandler(this.numberTwoPictureBox_Click);
            // 
            // numberThreePictureBox
            // 
            this.numberThreePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberThreePictureBox.Image = global::Flags.Properties.Resources.Three;
            this.numberThreePictureBox.Location = new System.Drawing.Point(193, 42);
            this.numberThreePictureBox.Name = "numberThreePictureBox";
            this.numberThreePictureBox.Size = new System.Drawing.Size(82, 146);
            this.numberThreePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.numberThreePictureBox.TabIndex = 6;
            this.numberThreePictureBox.TabStop = false;
            this.numberThreePictureBox.Click += new System.EventHandler(this.numberThreePictureBox_Click);
            // 
            // numberFourPictureBox
            // 
            this.numberFourPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberFourPictureBox.Image = global::Flags.Properties.Resources.Four;
            this.numberFourPictureBox.Location = new System.Drawing.Point(281, 42);
            this.numberFourPictureBox.Name = "numberFourPictureBox";
            this.numberFourPictureBox.Size = new System.Drawing.Size(82, 146);
            this.numberFourPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.numberFourPictureBox.TabIndex = 7;
            this.numberFourPictureBox.TabStop = false;
            this.numberFourPictureBox.Click += new System.EventHandler(this.numberFourPictureBox_Click);
            // 
            // numberFivePictureBox
            // 
            this.numberFivePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberFivePictureBox.Image = global::Flags.Properties.Resources.Five;
            this.numberFivePictureBox.Location = new System.Drawing.Point(369, 42);
            this.numberFivePictureBox.Name = "numberFivePictureBox";
            this.numberFivePictureBox.Size = new System.Drawing.Size(82, 146);
            this.numberFivePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.numberFivePictureBox.TabIndex = 8;
            this.numberFivePictureBox.TabStop = false;
            this.numberFivePictureBox.Click += new System.EventHandler(this.numberFivePictureBox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(471, 247);
            this.Controls.Add(this.numberFivePictureBox);
            this.Controls.Add(this.numberFourPictureBox);
            this.Controls.Add(this.numberThreePictureBox);
            this.Controls.Add(this.numberTwoPictureBox);
            this.Controls.Add(this.numberLabel);
            this.Controls.Add(this.instructionLable);
            this.Controls.Add(this.numberOnePictureBox);
            this.Name = "Form1";
            this.Text = "Flag";
            ((System.ComponentModel.ISupportInitialize)(this.numberOnePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numberTwoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numberThreePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numberFourPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numberFivePictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox numberOnePictureBox;
        private System.Windows.Forms.Label instructionLable;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.PictureBox numberTwoPictureBox;
        private System.Windows.Forms.PictureBox numberThreePictureBox;
        private System.Windows.Forms.PictureBox numberFourPictureBox;
        private System.Windows.Forms.PictureBox numberFivePictureBox;
    }
}

